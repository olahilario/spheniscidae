// Exercícios preparatórios


// 1 - Tabela de preços
// Uma loja precisa atualizar os preços de seus produtos, nesse exercício temos uma lista com os preços de cada produto
// Utilize o método map para criar um novo array, os produtos devem ser acrescidos de 20% do seu valor atual.

produtos = [15, 22.4, 30, 7, 12.4, 50, 100, 12, 1.99, 20]



// 2 - Um programa que lê identidades precisa verificar quem possui acesso ou não ao sistema
// Crie uma nova lista de convidados de forma que a lista não contenha nenhum convidado menor de 18 anos.
// Utilize o método "filter" para criar essa nova lista.
 
idadeDosConvidados =  [16, 22, 35, 20, ,14 , 17, 33, 72, 33, 25, 42, 21, 18]

// 3 - O cadastro de um funcionario foi realizado de forma incorreta.
// O nome está todo em caixa alta, o sobrenome está incorreto (é Diaz e não Dias)
// Altere as informações e depois imprima o objeto no terminal para ver se as correções foram aplicadas.

pessoa = {
    nome: 'JOÃO',
    sobrenome: 'Dias',
    idade: 34,
    profissao: 'soldador'
}

// 4 - Considere a seguinte lista de objetos:

let pessoas = [
    { nome: 'João', sobrenome: 'Silva', idade: 25, profissao: 'Engenheiro' },
    { nome: 'Maria', sobrenome: 'Santos', idade: 30, profissao: 'Professor' },
    { nome: 'Pedro', sobrenome: 'Oliveira', idade: 40, profissao: 'Médico' },
    { nome: 'Ana', sobrenome: 'Ferreira', idade: 35, profissao: 'Advogado' },
    { nome: 'Lucas', sobrenome: 'Costa', idade: 28, profissao: 'Designer' },
    { nome: 'Carla', sobrenome: 'Souza', idade: 22, profissao: 'Estudante' },
    { nome: 'Marcos', sobrenome: 'Almeida', idade: 38, profissao: 'Programador' },
    { nome: 'Juliana', sobrenome: 'Ribeiro', idade: 32, profissao: 'Psicóloga' },
    { nome: 'Rafael', sobrenome: 'Pereira', idade: 45, profissao: 'Empresário' },
    { nome: 'Camila', sobrenome: 'Gomes', idade: 27, profissao: 'Enfermeira' }
];


// 4.1 - Imprima para cada uma das pessoaqs na lista as informações nos seguinte formato:
// {nome completo} é {profissão} e tem {anos} anos de idade


// 4.2 Imagine que a lista diz respeito aos usuários de um determinado produto,a empresa decidiu adicionar uma nova informação para cada usuário: hobby; 
// Adicione um hobby para cada pessoa da lista. 


//4.2 Foi requisitado que você criasse um filtro para este dicionario a partir de caracteres;
// Se os carcteres ou caracter existirem no nome completo da pessoa, aquele cadastro deverá ser exibido.


//4.3 Crie um filtro que filtre as pessoas a partir de uma idade;

