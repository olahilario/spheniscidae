try {
   const resultado = 10/0 
   console.log(resultado)
} catch (error) {
    console.log(error.message)
}