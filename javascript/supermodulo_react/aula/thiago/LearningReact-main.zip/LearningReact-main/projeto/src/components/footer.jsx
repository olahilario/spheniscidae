import React from 'react'

function Footer() {
	return(
			<div>
				<p>Oshiro 2024</p>
			</div>
    )
}


export default Footer